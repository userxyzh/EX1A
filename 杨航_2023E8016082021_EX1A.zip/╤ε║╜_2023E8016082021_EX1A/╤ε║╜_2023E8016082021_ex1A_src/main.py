# coding=utf-8
import os
import sys
import time
from queue import Queue

from scapy import all as cap
from scapy.all import IP
from scapy.all import Padding
from scapy.all import Raw
from scapy.utils import hexdump


from PySide6 import QtWidgets
from PySide6 import QtCore
from PySide6.QtWidgets import QTableWidgetItem as QTItem
from PySide6.QtWidgets import QTreeWidgetItem as QRItem

from PySide6.QtWidgets import QMainWindow
from ui import main as main_ui
from logger import logger

DIRNAME = os.path.dirname(os.path.abspath(__file__))
MAXSIZE = 1024


class Signal(QtCore.QObject):

    recv = QtCore.Signal(None)


class MainWindow(QMainWindow):
   
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.ui = main_ui.Ui_MainWindow()
        self.ui.setupUi(self)

        self.sniffer = None
        self.counter = 0
        self.start_time = 0
        self.signal = Signal()
        self.queue = Queue()
     
        self.init_interfaces()
        
  

    def init_interfaces(self):
        for face in cap.get_working_ifaces():
            self.ui.interfaceBox.addItem(face.name)#找到网卡设备，把能用的写上去

        self.ui.startButton.clicked.connect(self.start_click)        
        self.ui.packetTable.horizontalHeader().setStretchLastSection(True)
        self.ui.packetTable.cellPressed.connect(self.update_content)
        self.ui.treeWidget.itemPressed.connect(self.update_layer_content)
        self.signal.recv.connect(self.update_packet)
        


    def get_iface(self):
        idx = self.ui.interfaceBox.currentIndex()
        iface = cap.get_working_ifaces()[idx]
        return iface
        
     

    def get_packet_layers(self, packet):#迭代获得包的不同层
        counter = 0
        while True:
            layer = packet.getlayer(counter)
            if layer is None:
                break
            yield layer           
            counter += 1

    def update_layer_content(self, item, column):
        if not hasattr(item, 'layer'):
            return
        layer = item.layer
        self.ui.contentEdit.setText(hexdump(layer, dump=True))

    def update_content(self, x, y):
        logger.debug("%s, %s clicked", x, y)
        item = self.ui.packetTable.item(x, 6)
        if not hasattr(item, 'packet'):
            return
        logger.debug(item)
        logger.debug(item.text())
        packet = item.packet
        self.ui.contentEdit.setText(hexdump(packet, dump=True))

        self.ui.treeWidget.clear()
        for layer in self.get_packet_layers(packet):
            item = QRItem(self.ui.treeWidget)
            item.layer = layer
            item.setText(0, layer.name)

            for name, value in layer.fields.items():
                child = QRItem(item)
                child.setText(0, f"{name}: {value}")
        
       
    def update_packet(self):
        packet = self.queue.get(False)
        if not packet:
            return

        if self.ui.packetTable.rowCount() >= MAXSIZE:
            self.ui.packetTable.removeRow(0)

        row = self.ui.packetTable.rowCount()
        

        # protocol
        xieyi = self.ui.protocolEdit.text().strip()

        layer = None
        for var in self.get_packet_layers(packet):
            if not isinstance(var, (Padding, Raw)):
                layer = var
        
        if xieyi =='':
            self.ui.packetTable.insertRow(row)
            protocol = layer.name
            self.ui.packetTable.setItem(row, 4, QTItem(str(protocol)))
        elif xieyi =='TCP':
            protocol = layer.name
            if xieyi == protocol:
                self.ui.packetTable.insertRow(row)
                self.ui.packetTable.setItem(row, 4, QTItem(str(protocol)))
            else:
                return
        elif xieyi =='UDP':
            protocol = layer.name
            if xieyi == protocol:
                self.ui.packetTable.insertRow(row)
                self.ui.packetTable.setItem(row, 4, QTItem(str(protocol)))
            else:
                return
        elif xieyi =='ARP':
            protocol = layer.name
            if xieyi == protocol:
                self.ui.packetTable.insertRow(row)
                self.ui.packetTable.setItem(row, 4, QTItem(str(protocol)))
            else:
                return
        
        # No.
        self.counter += 1
        self.ui.packetTable.setItem(row, 0, QTItem(str(self.counter)))
        
        # Time
        elapse = time.time() - self.start_time
        self.ui.packetTable.setItem(row, 1, QTItem(f"{elapse:2f}"))

        # source
        if IP in packet:
            src = packet[IP].src
            dst = packet[IP].dst
        else:
            src = packet.src
            dst = packet.dst

        self.ui.packetTable.setItem(row, 2, QTItem(src))

        # destination
        self.ui.packetTable.setItem(row, 3, QTItem(dst))

        
        # length
        length = f"{len(packet)}"
        self.ui.packetTable.setItem(row, 5, QTItem(length))

        # info

        info = str(packet.summary())
        item = QTItem(info)
        item.packet = packet
        self.ui.packetTable.setItem(row, 6, item)


    def sniff_action(self, packet):
        if not self.sniffer:
            return

        self.queue.put(packet)
        self.signal.recv.emit()

    def start_click(self):
        logger.debug("start button was clicked")
        if self.sniffer:
            self.sniffer.stop()
            self.sniffer = None
            self.ui.startButton.setText("Start")
            self.ui.interfaceBox.setEnabled(True)
            self.ui.protocolEdit.setEnabled(True)
            return

        xieyi = self.ui.protocolEdit.text()
        logger.debug("protocol %s", xieyi)

        iface = self.get_iface()
        logger.debug("sniffing interface %s", iface)

        self.sniffer = cap.AsyncSniffer(
            iface=iface,
            prn=self.sniff_action,
            filter=xieyi,
        )

        self.sniffer.start()
        self.counter = 0
        self.start_time = time.time()

        self.ui.startButton.setText("Stop")
        self.ui.interfaceBox.setEnabled(False)
        self.ui.protocolEdit.setEnabled(False)
        self.ui.packetTable.clearContents()
        self.ui.packetTable.setRowCount(0)
        self.ui.treeWidget.clear()
        self.ui.contentEdit.clear()


def main():
    
    app = QtWidgets.QApplication.instance()
    if app is None:         
        app = QtWidgets.QApplication.instance(sys.argv)
    
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
